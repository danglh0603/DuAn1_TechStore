package com.DuAn1.techstore.Database;

public class Server {
    public static String localhost = "https://duan1techstore.000webhostapp.com";
    public static String dangNhap = localhost+"/api/login.php";
    public static String dangKy = localhost+"/api/register.php";
    public static String getAllSP = localhost+"/api/getAll_SP.php";
    public static String yeuThich = localhost+"/api/yeuThich.php";
}
