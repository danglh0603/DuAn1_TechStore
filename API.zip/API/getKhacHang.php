<?php
if (isset($_POST['tenDangNhap'])) {
    require_once 'config.php';
    $tenDangNhap = $_POST['tenDangNhap'];
    $sql = mysqli_query($conn, "SELECT* FROM KhachHang WHERE tenDangNhap = '$tenDangNhap'");
    while ($row = mysqli_fetch_assoc($sql))
        $output[] = $row;
    print(json_encode($output));
    header('Content-Type: application/json');
    mysqli_close($connect);
}
