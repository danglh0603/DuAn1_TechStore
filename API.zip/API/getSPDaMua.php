<?php
if (isset($_POST['maKH'])) {
    require_once 'config.php';
    $maKH = $_POST['maKH'];
    //$maKH =11;

    $sql = mysqli_query($conn, "SELECT SanPham.maLoai, SanPham.maSP, SanPham.tenSP,SanPham.tenSP, SanPham.soLuongNhap,SanPham.hinhAnh, SanPham.giaTien,SanPham.giaCu, SanPham.ngayNhap,SanPham.thongTinSP FROM SanPham JOIN ChiTietHoaDon ON SanPham.maSP = ChiTietHoaDon.maSP JOIN HoaDon ON ChiTietHoaDon.maHD = HoaDon.maHD JOIN KhachHang ON HoaDon.maKH = KhachHang.maKH WHERE KhachHang.maKH = '$maKH' GROUP BY ChiTietHoaDon.maSP");
    if ($sql->num_rows  > 0) {
        while ($row = mysqli_fetch_assoc($sql))
            $output[] = $row;
        print(json_encode($output));
        header('Content-Type: application/json');
    } else {
        echo "failure";
    }
    mysqli_close($connect);
}
