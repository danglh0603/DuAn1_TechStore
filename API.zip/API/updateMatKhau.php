<?php
if (isset($_POST['maKH']) && isset($_POST['matKhau'])) {
    require_once "config.php";
    require_once "validate.php";

    $maKH = validate($_POST['maKH']);
    $matKhau = validate($_POST['matKhau']);
    //$maKH = 10;
    //$matKhau = "2002";


    $sql = "UPDATE `KhachHang` SET `matKhau` = '$matKhau' WHERE maKH = '$maKH'";
    if ($conn->query($sql)) {
        echo "sucess";
    } else {
        echo "failure" . $conn->error;
    }

    $conn->close();
}
