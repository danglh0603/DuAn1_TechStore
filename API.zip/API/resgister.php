<?php
if (isset($_POST['tenDangNhap']) && isset($_POST['matKhau']) && isset($_POST['tenKH']) && isset($_POST['namSinh']) && isset($_POST['soDienThoai']) && isset($_POST['diaChi'])) {
    // Include the necessary files
    require_once 'config.php';
    require_once "validate.php";
    //Call validate, pass form data as parameter and store the returned value
    $tenDangNhap = validate($_POST['tenDangNhap']);
    $matKhau = validate($_POST['matKhau']);
    $tenKH = validate($_POST['tenKH']);
    $namSinh = validate($_POST['namSinh']);
    $soDienThoai = validate($_POST['soDienThoai']);
    $diaChi = validate($_POST['diaChi']);

    // $email = "dang22@gmail.com";
    // $password = "123";
    // $diachi = "ha noi";
    // $sdt ="01234555";

    // Create the SQL query string. We'll use md5() function for data security. It calculates and returns the MD5 hash of a string
    $checkUsername = "select* from KhachHang where tenDangNhap= '$tenDangNhap'";
    $sql = "insert into KhachHang values(null,'$tenDangNhap', '$matKhau','$tenKH','$namSinh','$soDienThoai','$diaChi')";

    // Execute the query. Print "success" on a successful execution, otherwise "failure".
    if (!$conn->query($checkUsername)->num_rows > 0) {
        if (!$conn->query($sql)) {
            echo "failure";
        } else {
            echo "success";
        }
    } else {
        echo "usernamedatontai";
    }
}
