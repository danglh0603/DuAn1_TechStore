<?php
if (isset($_POST['maKH']) && isset($_POST['tenKH']) && isset($_POST['namSinh']) && isset($_POST['soDienThoai']) && isset($_POST['diaChi'])) {
    require_once "config.php";
    require_once "validate.php";

    $maKH = validate($_POST['maKH']);
    $tenKH = validate($_POST['tenKH']);
    $namSinh = validate($_POST['namSinh']);
    $soDienThoai = validate($_POST['soDienThoai']);
    $diaChi = validate($_POST['diaChi']);
    // $maKH = 10;
    // $tenKH = "bbbbb";
    // $namSinh = 2002;
    // $soDienThoai = "00011111";
    // $diaChi = "lao cai";

    $sql = "UPDATE `KhachHang` SET `tenKH`='$tenKH',`namSinh`='$namSinh',`soDienThoai`='$soDienThoai',`diaChi`='$diaChi' WHERE maKH = '$maKH'";
    if ($conn->query($sql)) {
        echo "sucess";
    } else {
        echo "failure" . $conn->error;
    }
    $conn->close();
}
