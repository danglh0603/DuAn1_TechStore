<?php
if (isset($_POST['maSP']) && isset($_POST['maKH'])) {
    //import file
    require_once "config.php";
    require_once "validate.php";

    $maSP = validate($_POST['maSP']);
    $maKH = validate($_POST['maKH']);


    $sql = "DELETE FROM `GioHang` WHERE maSP = '$maSP' AND maKH ='$maKH'";
    if ($conn->query($sql)) {
        echo "success";
    } else {
        echo "failure";
    }
}
