<?php
if (isset($_POST['maHD'])) {
    require_once 'config.php';
    $maHD = $_POST['maHD'];
    //$maHD = 115;

    $sql = mysqli_query($conn, "SELECT * FROM `ChiTietHoaDon` WHERE maHD = '$maHD'");
    if ($sql->num_rows  > 0) {
        while ($row = mysqli_fetch_assoc($sql))
            $output[] = $row;
        print(json_encode($output));
        header('Content-Type: application/json');
    } else {
        echo "failure";
    }
    mysqli_close($connect);
}
