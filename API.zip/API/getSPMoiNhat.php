
<?php
// lấy 30 sp mới nhất
require_once 'config.php';
$sql = mysqli_query($conn, "SELECT * FROM SanPham ORDER BY ngayNhap DESC LIMIT 30");
while ($row = mysqli_fetch_assoc($sql))
    $output[] = $row;
print(json_encode($output));
header('Content-Type: application/json');
mysqli_close($connect);
?>
