<?php
if (isset($_POST['maKH']) && isset($_POST['tongTien'])) {
    require_once "config.php";
    require_once "validate.php";

    $maKH = validate($_POST['maKH']);
    $tongTien = validate($_POST['tongTien']);
    // $maKH = 6;
    // $tongTien = 20001;

    $sql = "INSERT INTO `HoaDon` (`maHD`, `maKH`, `tongTien`) VALUES (NULL, '$maKH','$tongTien')";
    // Execute the query
    if (!$conn->query($sql)) {
        echo "failure";
    } else {
        $maHD = $conn->insert_id;
        $output[] = $maHD;
        print(json_encode($output));
        header('Content-Type: application/json');
    }
    mysqli_close($connect);
}
