<?php
// Check nếu tenDangNhap và mật khẩu tồn tại
if (isset($_POST['tenDangNhap']) && isset($_POST['matKhau'])) {
    //import file
    require_once "config.php";
    require_once "validate.php";
    //validate và POST tenDangNhap, matKhau
    $tenDangNhap = validate($_POST['tenDangNhap']);
    $matKhau = validate($_POST['matKhau']);
    // test:
    // $tenDangNhap = "danglh";
    // $matKhau = "1234";

    $sql = "select * from KhachHang where tenDangNhap='$tenDangNhap' and matKhau='$matKhau'";
    // Execute the query
    $result = $conn->query($sql);
    // If number of rows returned is greater than 0 (that is, if the record is found), we'll print "success", otherwise "failure"
    if ($result->num_rows > 0) {
        echo "success";
    } else {
        // If no record is found, print "failure"
        echo "failure";
    }
}
