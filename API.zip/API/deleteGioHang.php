<?php
if (isset($_POST['maKH'])) {
    //import file
    require_once "config.php";
    require_once "validate.php";

    $maKH = validate($_POST['maKH']);


    $sql = "DELETE FROM GioHang WHERE maKH = '$maKH'";
    if ($conn->query($sql)) {
        echo "success";
    } else {
        echo "failure";
    }
}
