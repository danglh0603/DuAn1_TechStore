
<?php
if (isset($_POST['maHD']) && isset($_POST['maSP']) && isset($_POST['soLuongMua']) && isset($_POST['donGia'])) {
    require_once "config.php";
    require_once "validate.php";

    $maHD = validate($_POST['maHD']);
    $maSP = validate($_POST['maSP']);
    $soLuongMua = validate($_POST['soLuongMua']);
    $donGia = validate($_POST['donGia']);

    $sql = "INSERT INTO `ChiTietHoaDon` (`maHD`, `maSP`, `soLuongMua`, `donGia`) VALUES ('$maHD', '$maSP', '$soLuongMua', '$donGia')";
    // Execute the query
    if (!$conn->query($sql)) {
        echo "failure";
    } else {
        echo "success";
    }
    mysqli_close($connect);
}
?>