<?php
if (isset($_POST['maSP'])) {
    require_once 'config.php';
    $maSP = $_POST['maSP'];
    //$maHD = 115;

    $sql = mysqli_query($conn, "SELECT * FROM `SanPham` WHERE maSP = '$maSP'");
    if ($sql->num_rows  > 0) {
        while ($row = mysqli_fetch_assoc($sql))
            $output[] = $row;
        print(json_encode($output));
        header('Content-Type: application/json');
    } else {
        echo "failure";
    }
    mysqli_close($connect);
}
