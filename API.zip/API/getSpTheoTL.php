<?php
if (isset($_POST['maLoai'])) {
    require_once 'config.php';
    $maLoai = $_POST['maLoai'];
    $sql = mysqli_query($conn, "SELECT* FROM SanPham WHERE maLoai = '$maLoai'");
    while ($row = mysqli_fetch_assoc($sql))
        $output[] = $row;
    print(json_encode($output));
    header('Content-Type: application/json');
    mysqli_close($connect);
}
