<?php
if (isset($_POST['maSP']) && isset($_POST['maKH']) && isset($_POST['soLuongMua'])) {
    require_once "config.php";
    require_once "validate.php";

    $maSP = $_POST['maSP'];
    $maKH = $_POST['maKH'];
    $soLuongMua = $_POST['soLuongMua'];

    $sql = "INSERT INTO GioHang VALUES ('$maSP','$maKH','$soLuongMua')";
    // Execute the query
    if (!$conn->query($sql) === TRUE) {
        echo "failure";
    } else {
        echo "success";
    }
    mysqli_close($connect);
}
