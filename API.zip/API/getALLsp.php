<?php
require_once 'config.php';

$sql = mysqli_query($conn, "SELECT* FROM SanPham");
while ($row = mysqli_fetch_assoc($sql))
    $output[] = $row;
print(json_encode($output));
header('Content-Type: application/json');
mysqli_close($connect);
