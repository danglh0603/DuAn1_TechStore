<?php
if (isset($_POST['maKH'])) {
    require_once 'config.php';
    $maKH = $_POST['maKH'];
    //$maKH = 7;
    $sql = mysqli_query($conn, "SELECT SanPham.maLoai, GioHang.maSP,GioHang.maKH,SanPham.tenSP,SanPham.soLuongNhap, SanPham.hinhAnh, SanPham.giaTien, SanPham.giaCu,SanPham.ngayNhap, SanPham.thongTinSP, SUM(soLuongMua)AS soLuong FROM GioHang INNER JOIN SanPham ON GioHang.maSP = SanPham.maSP WHERE maKH = '$maKH' GROUP BY maSP");

    if ($sql->num_rows  > 0) {
        while ($row = mysqli_fetch_assoc($sql))
            $output[] = $row;
        print(json_encode($output));
        header('Content-Type: application/json');
    } else {
        echo "failure";
    }
    mysqli_close($connect);
}
