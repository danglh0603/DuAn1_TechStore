
<?php
    $servername = "localhost";
    $username = "id17920136_duan1";
    $password = "*U}wLc$9~aVw-gVp";
    $dbname = "id17920136_db_techstore";

    $connect = mysqli_connect($servername,$username,$password);
    mysqli_select_db($connect,$dbname);
    $sql=mysqli_query($connect,"SELECT* FROM TheLoai");
    if($sql === FALSE) {
        die(mysqli_error($connect)); // TODO: better error handling
    }
    while($row=mysqli_fetch_assoc($sql))
        $output[]=$row;
    print(json_encode($output));
    mysqli_close($connect);

            
?>