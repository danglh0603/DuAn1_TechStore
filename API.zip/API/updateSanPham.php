<?php
if (isset($_POST['soLuongNhap']) && isset($_POST['maSP'])) {
    require_once "config.php";
    require_once "validate.php";

    $soLuongNhap = validate($_POST['soLuongNhap']);
    $maSP = validate($_POST['maSP']);

    $sql = "UPDATE SanPham SET soLuongNhap = '$soLuongNhap' WHERE maSP = '$maSP'";
    if ($conn->query($sql)) {
        echo "sucess";
    } else {
        echo "failure" . $conn->error;
    }

    $conn->close();
}
