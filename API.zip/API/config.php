<?php
// Create 4 variables to store these information
$servername = "localhost";
$username = "id17920136_duan1";
$password = "*U}wLc$9~aVw-gVp";
$dbname = "id17920136_db_techstore";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
